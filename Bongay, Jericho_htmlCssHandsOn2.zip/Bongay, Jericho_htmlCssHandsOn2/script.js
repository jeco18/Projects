function register() {
    let fname = document.getElementById("firstName").value;
    
    alert("Hi! " + fname + " your account is successfully registered!");   
}

function login() {
    const user = ["user", "admin", "test", "test3", "none"];
    const pass = ["password", "pass", "test", "test3", "none"];
    let username = document.getElementById("user").value;
    let password = document.getElementById("password").value;
  
    for (var i=0; i<user.length; i++) {
        if ((username === user[i]) && (password === pass[i])) {
            alert("Login Successful");
                // match found
        }
}
alert("Check username and password"); // match not found
}

function resetPassword() {
    var newpassword = document.getElementById('newPassword').value;
    var confirmpassword = document.getElementById('confirmPassword').value;
    if (newpassword == "" || confirmpassword == "") {
        alert("Please put a new password");
    }
    else if (newpassword == confirmpassword) {
        alert("Password reset successful!");
    }
    else if (newpassword != confirmpassword) {
        alert("Password did not match");
    }
}
